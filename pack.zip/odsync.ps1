# Define the folder paths
$folderPath = "D:\OneDrive - NTriver\Windows_11_LTSC_2024"
$sourceFolderPath = "D:\d"
$maxConcurrentUploads = 5

# Start an infinite loop
while ($true) {
    try {
        # Initialize Shell.Application COM object
        $shell = New-Object -ComObject Shell.Application
        $folder = $shell.Namespace($folderPath)

        if (-not $folder) {
            Write-Host "Could not access the folder: $folderPath"
            Start-Sleep -Seconds 60
            continue
        }

        $statusColumnIndex = -1
        for ($i = 0; $i -lt 50; $i++) {
            if ($folder.GetDetailsOf($null, $i) -eq "Status") {
                $statusColumnIndex = $i
                break
            }
        }


        function Process-Folder {
            param (
                [string]$path,
                [string]$baseFolderPath
            )

            $syncPendingCount = 0
            $isoFiles = @()

            $currentFolder = $shell.Namespace($path)

            if (-not $currentFolder) {
                Write-Host "Could not access subfolder: $path"
                return @{
                    SyncPendingCount = $syncPendingCount
                    IsoFiles = $isoFiles
                }
            }

            foreach ($item in $currentFolder.Items()) {
                if ($item.IsFolder) {
                    $subfolderResult = Process-Folder -path $item.Path -baseFolderPath $baseFolderPath
                    $syncPendingCount += $subfolderResult.SyncPendingCount
                    $isoFiles += $subfolderResult.IsoFiles
                } else {
                    $status = $currentFolder.GetDetailsOf($item, $statusColumnIndex)

                    if ($status -and $status -match "Availability status: (.+)") {
                        $availabilityStatus = $matches[1].Trim()
                        $relativePath = $item.Path.Replace($baseFolderPath, "").TrimStart("\")
                        $formattedOutput = "{0,-60} {1}" -f $relativePath, $availabilityStatus
                        Write-Output $formattedOutput

                        if ($availabilityStatus -eq "Available on this device") {
                            $filePath = $item.Path
                            try {
                                attrib +U -P $filePath
                                Write-Output "Freed up file: $filePath"
                            } catch {
                                Write-Output "Failed to free up file: $filePath. Error: $_"
                            }
                        }

                        if ($availabilityStatus -eq "Sync pending") {
                            $syncPendingCount++
                        }
                    }

                    if ($item.Path -match "\.iso$") {
                        $isoFiles += $item.Path
                    }
                }
            }

            return @{
                SyncPendingCount = $syncPendingCount
                IsoFiles = $isoFiles
            }
        }

        $targetFolderResult = Process-Folder -path $folderPath -baseFolderPath $folderPath

        if ($targetFolderResult.SyncPendingCount -lt $maxConcurrentUploads) {
            $filesToMoveCount = $maxConcurrentUploads - $targetFolderResult.SyncPendingCount

            $sourceFolderResult = Process-Folder -path $sourceFolderPath -baseFolderPath $sourceFolderPath

            $filesMoved = 0
            foreach ($isoFile in $sourceFolderResult.IsoFiles) {
                if ($filesMoved -ge $filesToMoveCount) {
                    break
                }

                $destinationPath = Join-Path -Path $folderPath -ChildPath ([System.IO.Path]::GetFileName($isoFile))
                try {
                    Move-Item -Path $isoFile -Destination $destinationPath
                    Write-Output "Moved file: $isoFile to $destinationPath"
                    $filesMoved++
                } catch {
                    Write-Output "Failed to move file: $isoFile. Error: $_"
                }
            }
        }
    } catch {
        Write-Host "An error occurred: $_"
    }

    # Wait for 1 minute before the next iteration
    Start-Sleep -Seconds 60
}
