<#
.SYNOPSIS
    Monitors a folder for SVF extraction files.

.DESCRIPTION
    Every 60 seconds:
    1. Reads list_cart.txt to get the expected output filenames.
    2. Runs smv.exe l on all .svf files and captures the output.
    3. Finds all files excluding .txt, .svf, and .HASH.
    4. Compares these files against the smv output:
        - If found in smv output, leaves them alone.
        - If not found in smv output, and present in list_cart.txt, moves them to the destination.
        - If not found in smv output, and not present in list_cart.txt, deletes them.
#>

# ==============================================================================
# VARIABLES TO CONFIGURE
# ==============================================================================
$TargetFolder    = "D:\cat\23728" # <-- SET THIS to your target folder path
$MoveDestination = "D:\final"     # <-- Set to your move destination

Write-Host "Starting SVF monitor on $TargetFolder..."
Write-Host "Press Ctrl+C to stop."

while ($true) {
    try {
        # ----------------------------------------------------------------------
        # 1. Variable 1: Get files listed in list_cart.txt
        # ----------------------------------------------------------------------
        $ListCartPath = Join-Path -Path $TargetFolder -ChildPath "list_cart.txt"
        $Var1_CartFiles = @()
        
        if (Test-Path -Path $ListCartPath) {
            $CartContent = Get-Content -Path $ListCartPath
            foreach ($line in $CartContent) {
                # Split the line by the pipe character '|'
                $parts = $line -split '\|'
                # The file name is the second item (index 1)
                if ($parts.Count -ge 2) {
                    $Var1_CartFiles += $parts[1].Trim()
                }
            }
        }

        # ----------------------------------------------------------------------
        # 2. Variable 2: Gather all .SVF files and run smv.exe l [SvfFile]
        # ----------------------------------------------------------------------
        $Var2_SmvOutput = ""
        $SmvExePath = Join-Path -Path $PSScriptRoot -ChildPath "smv.exe"
        $SvfFiles = Get-ChildItem -Path $TargetFolder -Filter "*.svf" -File
        
        if (Test-Path -Path $SmvExePath) {
            foreach ($svf in $SvfFiles) {
                # Run smv.exe l and capture output (redirect stderr to stdout to catch everything)
                $output = & $SmvExePath l $svf.FullName 2>&1
                $Var2_SmvOutput += ($output | Out-String)
            }
        }

        # ----------------------------------------------------------------------
        # 3. Variable 3: List all files excluding .txt, .svf, and .HASH
        # ----------------------------------------------------------------------
        # We also exclude smv.exe itself so we don't accidentally move/delete it
        $Var3_OtherFiles = Get-ChildItem -Path $TargetFolder -File | Where-Object {
            $_.Extension -notin @('.txt', '.svf', '.HASH', '.hash') -and $_.Name -ne 'smv.exe'
        }

        # ----------------------------------------------------------------------
        # 4. Compare and act on the files in Variable 3
        # ----------------------------------------------------------------------
        foreach ($file in $Var3_OtherFiles) {
            $fileName = $file.Name
            
            # Check if this file name is found in the smv multiline output (Variable 2)
            if ($Var2_SmvOutput -match [regex]::Escape($fileName)) {
                # Found in smv output -> Needed for ongoing process. Don't touch.
                # Write-Host "Skipping $fileName (needed for ongoing process)"
            } else {
                # Not found in Variable 2 -> Done files
                # Check if this file exists in Variable 1 (list_cart.txt)
                if ($Var1_CartFiles -contains $fileName) {
                    # Move to destination folder
                    if (-not (Test-Path -Path $MoveDestination)) {
                        New-Item -ItemType Directory -Path $MoveDestination -Force | Out-Null
                    }
                    Write-Host "[$(Get-Date -Format 'HH:mm:ss')] Moving done file to destination: $fileName"
                    Move-Item -Path $file.FullName -Destination $MoveDestination -Force
                } else {
                    # Not found in Variable 1 either -> Delete it
                    Write-Host "[$(Get-Date -Format 'HH:mm:ss')] Deleting unneeded file: $fileName"
                    Remove-Item -Path $file.FullName -Force
                }
            }
        }
    } catch {
        Write-Error "An error occurred during the loop iteration: $_"
    }

    # Wait 60 seconds before next scan
    Start-Sleep -Seconds 60
}
