[CmdletBinding()]
param (
    [Parameter(Mandatory=$false)]
    [string]$Repo = "", # e.g. "owner/repo"

    [string]$BaseDir = "D:\gitup",

    [int]$MaxConcurrentJobs = 5
)

# Configuration
$LogFile = if ($PSScriptRoot) { Join-Path $PSScriptRoot "gh_upload_log.txt" } else { Join-Path $PWD "gh_upload_log.txt" }

$activeJobs = @{} # Dictionary to map File FullName to Process object
$knownReleases = @{} # Dictionary to cache known releases

if ([string]::IsNullOrWhiteSpace($Repo)) {
    if ([string]::IsNullOrWhiteSpace($env:GITHUB_REPOSITORY)) {
        Write-Host "Warning: No -Repo parameter provided and GITHUB_REPOSITORY environment variable is not set. gh CLI will try to infer the repository from the current directory's git context, which might fail if `$BaseDir is not a git repository." -ForegroundColor Yellow
    } else {
        $Repo = $env:GITHUB_REPOSITORY
        Write-Host "Auto-detected repository from GITHUB_REPOSITORY: $Repo" -ForegroundColor Cyan
    }
}

Write-Host "Starting continuous GitHub Release upload monitor..."

while ($true) {
    # 1. Clean up finished jobs
    $finishedFiles = @()
    foreach ($key in $activeJobs.Keys) {
        $process = $activeJobs[$key]
        if ($process.HasExited) {
            $finishedFiles += $key
            
            # Check if upload failed
            if ($process.ExitCode -ne 0) {
                Write-Host "Upload failed for $key with ExitCode $($process.ExitCode). Will retry in future scans." -ForegroundColor Red
                "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') - FAILED: $key" | Out-File -FilePath $LogFile -Append
            } else {
                "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') - DONE: $key" | Out-File -FilePath $LogFile -Append
            }
            
            $process.Dispose()
        }
    }
    
    foreach ($fileKey in $finishedFiles) {
        $activeJobs.Remove($fileKey)
    }
    
    # 2. Start new jobs if we have capacity
    if ($activeJobs.Count -lt $MaxConcurrentJobs) {
        $startedNewJob = $false
        
        if (Test-Path $BaseDir) {
            # Get all subfolders (1st level only)
            $subfolders = Get-ChildItem -Path $BaseDir -Directory
            
            foreach ($folder in $subfolders) {
                if ($activeJobs.Count -ge $MaxConcurrentJobs) {
                    break
                }
                
                $tagName = $folder.Name
                $files = @(Get-ChildItem -Path $folder.FullName -File | Where-Object { $_.Extension -ne ".fdmdownload" })
                
                if ($files.Count -eq 0) {
                    continue
                }
                
                # Check if release exists, if not, create it
                if (-not $knownReleases.ContainsKey($tagName)) {
                    Write-Host "Verifying release $tagName exists..."
                    $repoArgs = if (-not [string]::IsNullOrWhiteSpace($Repo)) { @("--repo", $Repo) } else { @() }
                    
                    $viewOutput = gh release view $tagName @repoArgs 2>&1
                    if ($LASTEXITCODE -ne 0) {
                        Write-Host "Creating release $tagName..."
                        $createOutput = gh release create $tagName @repoArgs --title $tagName --notes "Release $tagName" 2>&1
                        if ($LASTEXITCODE -ne 0) {
                            Write-Host "Failed to create release $tagName. Error: $createOutput" -ForegroundColor Red
                            continue
                        }
                    }
                    $knownReleases[$tagName] = $true
                }
                
                foreach ($file in $files) {
                    if ($activeJobs.Count -ge $MaxConcurrentJobs) {
                        break
                    }
                    
                    # Skip if currently uploading
                    if ($activeJobs.ContainsKey($file.FullName)) {
                        continue
                    }
                    
                    Write-Host "Starting upload for $($file.Name) to tag $tagName (Active: $($activeJobs.Count + 1) / $MaxConcurrentJobs)"
                    
                    $repoArgWorker = if (-not [string]::IsNullOrWhiteSpace($Repo)) { "--repo `"$Repo`"" } else { "" }
                    
                    # Build the command block to run in the new window
                    $workerScript = @"
& gh release upload "$tagName" "$($file.FullName)" $repoArgWorker --clobber
`$exitCode = `$LASTEXITCODE
if (`$exitCode -eq 0) {
    Remove-Item -Path "$($file.FullName)" -Force -ErrorAction Ignore
}
exit `$exitCode
"@
                    # Encode the script block to base64 to avoid quote escaping issues
                    $encodedCommand = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($workerScript))
                    
                    # Start the new process in a new minimized window
                    try {
                        $process = Start-Process powershell.exe -WindowStyle Minimized -ArgumentList "-NoProfile -EncodedCommand $encodedCommand" -PassThru -ErrorAction Stop
                        $activeJobs[$file.FullName] = $process
                        $startedNewJob = $true
                    } catch {
                        Write-Host "Failed to start process for $($file.FullName): $_" -ForegroundColor Red
                    }
                }
            }
        } else {
            Write-Host "Base directory '$BaseDir' does not exist yet." -ForegroundColor Yellow
        }
        
        if (-not $startedNewJob) {
            # No files to process right now, wait a bit
            Start-Sleep -Seconds 5
        }
    } else {
        # At max capacity, wait for a job to finish
        Start-Sleep -Seconds 2
    }
}
