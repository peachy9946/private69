# Define the folder paths
$folderPath = "D:\Mahakal\2OD2 - Documents\Server_2012_Part2"
$sourceFolderPath = "D:\final"
$maxConcurrentUploads = 12

# Ethernet Upload Monitor Variables
$AdapterName = "Ethernet 3"
$UploadSpeedCheckCount = 3
$UploadSpeedThresholdMBps = 3
$UploadSpeeds = @()
$LastOutboundBytes = $null
$LastCheckTime = $null

# Start an infinite loop
Write-Output "Starting ODsync script... Press Ctrl+C to stop."
while ($true) {
    try {
        Write-Output "[$((Get-Date).ToString())] Starting folder sync check for: $folderPath"
        # Initialize Shell.Application COM object
        $shell = New-Object -ComObject Shell.Application
        $folder = $shell.Namespace($folderPath)

        if (-not $folder) {
            Write-Host "Could not access the folder: $folderPath"
            Start-Sleep -Seconds 60
            continue
        }

        $statusColumnIndex = -1
        for ($i = 0; $i -lt 50; $i++) {
            if ($folder.GetDetailsOf($null, $i) -eq "Status") {
                $statusColumnIndex = $i
                break
            }
        }


        function Process-Folder {
            param (
                [string]$path,
                [string]$baseFolderPath
            )

            $syncPendingCount = 0
            $isoFiles = @()

            $currentFolder = $shell.Namespace($path)

            if (-not $currentFolder) {
                Write-Host "Could not access subfolder: $path"
                return @{
                    SyncPendingCount = $syncPendingCount
                    IsoFiles = $isoFiles
                }
            }

            foreach ($item in $currentFolder.Items()) {
                if ($item.IsFolder) {
                    $subfolderResult = Process-Folder -path $item.Path -baseFolderPath $baseFolderPath
                    $syncPendingCount += $subfolderResult.SyncPendingCount
                    $isoFiles += $subfolderResult.IsoFiles
                } else {
                    $status = $currentFolder.GetDetailsOf($item, $statusColumnIndex)

                    if ($status -and $status -match "Availability status: (.+)") {
                        $availabilityStatus = $matches[1].Trim()
                        $relativePath = $item.Path.Replace($baseFolderPath, "").TrimStart("\")
                        $formattedOutput = "{0,-60} {1}" -f $relativePath, $availabilityStatus
                        Write-Output $formattedOutput

                        if ($availabilityStatus -eq "Available on this device") {
                            $filePath = $item.Path
                            try {
                                attrib +U -P $filePath
                                Write-Output "Freed up file: $filePath"
                            } catch {
                                Write-Output "Failed to free up file: $filePath. Error: $_"
                            }
                        }

                        if ($availabilityStatus -eq "Sync pending") {
                            $syncPendingCount++
                        }
                    }

                    if ($item.Path -match "\.iso$") {
                        $isoFiles += $item.Path
                    }
                }
            }

            return @{
                SyncPendingCount = $syncPendingCount
                IsoFiles = $isoFiles
            }
        }

        $targetFolderResult = Process-Folder -path $folderPath -baseFolderPath $folderPath

        if ($targetFolderResult.SyncPendingCount -lt $maxConcurrentUploads) {
            $filesToMoveCount = $maxConcurrentUploads - $targetFolderResult.SyncPendingCount

            $sourceFolderResult = Process-Folder -path $sourceFolderPath -baseFolderPath $sourceFolderPath

            $filesMoved = 0
            foreach ($isoFile in $sourceFolderResult.IsoFiles) {
                if ($filesMoved -ge $filesToMoveCount) {
                    break
                }

                $destinationPath = Join-Path -Path $folderPath -ChildPath ([System.IO.Path]::GetFileName($isoFile))
                try {
                    Move-Item -Path $isoFile -Destination $destinationPath
                    Write-Output "Moved file: $isoFile to $destinationPath"
                    $filesMoved++
                } catch {
                    Write-Output "Failed to move file: $isoFile. Error: $_"
                }
            }
        }
    } catch {
        Write-Host "An error occurred: $_"
    }

    # Ethernet Upload Speed Check
    try {
        Write-Output "[$((Get-Date).ToString())] Checking network adapter: $AdapterName"
        $NetStats = Get-NetAdapterStatistics -Name $AdapterName -ErrorAction Stop | Select-Object -First 1
        $CurrentOutboundBytes = $NetStats.SentBytes
        $CurrentTime = Get-Date

        if ($null -ne $LastOutboundBytes -and $null -ne $LastCheckTime) {
            $TimeDiffSeconds = ($CurrentTime - $LastCheckTime).TotalSeconds
            if ($TimeDiffSeconds -gt 0) {
                $BytesSent = $CurrentOutboundBytes - $LastOutboundBytes
                if ($BytesSent -lt 0) { $BytesSent = 0 } # Handle potential counter rollover
                
                $SpeedMBps = ($BytesSent / $TimeDiffSeconds) / 1MB
                Write-Output "[$($CurrentTime.ToString())] Current upload speed: $([math]::Round($SpeedMBps, 2)) MB/s"
                
                $UploadSpeeds += $SpeedMBps
                if ($UploadSpeeds.Count -gt $UploadSpeedCheckCount) {
                    $UploadSpeeds = @($UploadSpeeds | Select-Object -Last $UploadSpeedCheckCount)
                }

                if ($UploadSpeeds.Count -eq $UploadSpeedCheckCount) {
                    $AverageSpeedMBps = ($UploadSpeeds | Measure-Object -Average).Average
                    Write-Output "[$($CurrentTime.ToString())] Average upload speed over last $UploadSpeedCheckCount checks: $([math]::Round($AverageSpeedMBps, 2)) MB/s"

                    if ($AverageSpeedMBps -lt $UploadSpeedThresholdMBps) {
                        Write-Output "[$($CurrentTime.ToString())] Average upload speed is below $UploadSpeedThresholdMBps MB/s. Restarting OneDrive..."
                        
                        # Stop OneDrive processes
                        Get-Process -Name "*onedrive*" -ErrorAction SilentlyContinue | Stop-Process -Force
                        
                        # Start OneDrive
                        $OneDrivePath = Join-Path $env:LOCALAPPDATA "Microsoft\OneDrive\OneDrive.exe"
                        if (Test-Path $OneDrivePath) {
                            Start-Process -FilePath $OneDrivePath
                            Write-Output "[$($CurrentTime.ToString())] OneDrive started."
                        } else {
                            Write-Warning "[$($CurrentTime.ToString())] OneDrive executable not found at: $OneDrivePath"
                        }
                        
                        # Clear history so we don't trigger it again immediately
                        $UploadSpeeds = @()
                    }
                }
            }
        } else {
            Write-Output "[$($CurrentTime.ToString())] Initializing baseline for network speed check. Next check will show speed."
        }
        $LastOutboundBytes = $CurrentOutboundBytes
        $LastCheckTime = $CurrentTime
    } catch {
        Write-Warning "[$((Get-Date).ToString())] Failed to get Ethernet statistics: $_"
    }

    # Wait for 1 minute before the next iteration
    Start-Sleep -Seconds 60
}
